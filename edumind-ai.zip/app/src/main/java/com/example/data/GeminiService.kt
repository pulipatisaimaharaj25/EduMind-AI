package com.example.data

import com.example.BuildConfig
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.ResponseBody
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// --- Moshi Request & Response Classes ---

@JsonClass(generateAdapter = true)
data class GenerateContentRequest(
    val contents: List<Content>,
    val generationConfig: GenerationConfig? = null,
    val systemInstruction: Content? = null
)

@JsonClass(generateAdapter = true)
data class Content(
    val parts: List<Part>
)

@JsonClass(generateAdapter = true)
data class Part(
    val text: String? = null
)

@JsonClass(generateAdapter = true)
data class GenerationConfig(
    val responseMimeType: String? = null,
    val temperature: Float? = null,
    val topP: Float? = null,
    val topK: Int? = null
)

@JsonClass(generateAdapter = true)
data class GenerateContentResponse(
    val candidates: List<Candidate>? = null
)

@JsonClass(generateAdapter = true)
data class Candidate(
    val content: Content? = null
)

// --- Retrofit Interface ---

interface GeminiApiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): GenerateContentResponse
}

// --- Moshi Object & Retrofit Client ---

object RetrofitClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val moshi: Moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    val service: GeminiApiService by lazy {
        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
        retrofit.create(GeminiApiService::class.java)
    }
}

// --- Gemini API Call Manager ---

object GeminiService {
    
    private fun getApiKey(): String {
        val apiKey = BuildConfig.GEMINI_API_KEY
        return if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            // Fallback default key just to avoid crashing if empty, but users must configure it
            ""
        } else {
            apiKey
        }
    }

    /**
     * Solves a student's doubt in simple English or Telugu depending on the language selection.
     */
    suspend fun solveDoubt(
        subject: String,
        question: String,
        classLevel: String,
        isTelugu: Boolean
    ): String = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isEmpty()) return@withContext "API Key is missing! Please configure GEMINI_API_KEY in the Secrets panel."

        val languagePrompt = if (isTelugu) {
            "Answer the student's question in Telugu language. Use very simple terms suitable for a student."
        } else {
            "Answer in very simple English. Avoid high-level vocabulary. Explain step-by-step as if explaining to a rural school student in India."
        }

        val prompt = """
            Student Class: $classLevel standard
            Subject: $subject
            Doubt/Question: $question
            
            Instruction: $languagePrompt
            Keep the answer clear, encouraging, structured with bullet points or simple lines, and brief.
        """.trimIndent()

        val request = GenerateContentRequest(
            contents = listOf(Content(parts = listOf(Part(text = prompt)))),
            systemInstruction = Content(parts = listOf(Part(text = "You are EduMind AI, an exceptionally supportive, friendly, and expert study assistant for rural Indian school students. You explain complex ideas in extremely simple, step-by-step terms with easy-to-understand real life examples from Indian village or town contexts.")))
        )

        try {
            val response = RetrofitClient.service.generateContent(apiKey, request)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text 
                ?: "Sorry, I could not generate an answer. Please try again."
        } catch (e: Exception) {
            "Error explaining doubt: ${e.localizedMessage ?: e.message}"
        }
    }

    /**
     * Generates a 5 MCQ quiz in JSON format based on subject, class, difficulty, and language.
     */
    suspend fun generateQuiz(
        subject: String,
        classLevel: String,
        difficulty: String,
        isTelugu: Boolean
    ): String = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isEmpty()) return@withContext "API Key is missing!"

        val languagePref = if (isTelugu) {
            "Questions and options should be in Telugu (with simple English terms in brackets if necessary)."
        } else {
            "Questions and options must be in very simple English suitable for rural students."
        }

        val prompt = """
            Generate a set of exactly 5 multiple-choice questions (MCQs) for a quiz.
            Subject: $subject
            Class Level: $classLevel standard
            Difficulty Level: $difficulty (Easy, Medium, Hard)
            Language requirement: $languagePref

            You MUST respond ONLY with a raw JSON object matching this exact schema:
            {
              "questions": [
                {
                  "question": "Question text...",
                  "options": ["Option A", "Option B", "Option C", "Option D"],
                  "correctIndex": 0,
                  "explanation": "Simple explanation of the correct option..."
                }
              ]
            }

            Rules:
            1. Response must be valid JSON, do NOT wrap in markdown code blocks like ```json ... ```.
            2. options must contain exactly 4 options.
            3. correctIndex must be an integer (0 for first option, 1 for second, 2 for third, 3 for fourth).
            4. Make questions fun, educational, and relevant to the student's grade.
        """.trimIndent()

        val request = GenerateContentRequest(
            contents = listOf(Content(parts = listOf(Part(text = prompt)))),
            generationConfig = GenerationConfig(responseMimeType = "application/json", temperature = 0.5f)
        )

        try {
            val response = RetrofitClient.service.generateContent(apiKey, request)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: ""
        } catch (e: Exception) {
            ""
        }
    }

    /**
     * Generates a day-by-day study schedule in JSON format.
     */
    suspend fun generateStudyPlan(
        examName: String,
        examDate: String,
        subjects: List<String>,
        classLevel: String
    ): String = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isEmpty()) return@withContext "API Key is missing!"

        val subjectsString = subjects.joinToString(", ")
        val prompt = """
            Create a personalized day-by-day study schedule plan for a student preparing for an exam.
            Student Class: $classLevel standard
            Exam Name: $examName
            Exam Date/Timeframe: $examDate
            Subjects to Cover: $subjectsString

            You MUST respond ONLY with a raw JSON object matching this exact schema:
            {
              "exam_name": "$examName",
              "days": [
                {
                  "day": "Day 1",
                  "focus_subject": "Math",
                  "topics": ["Numbers system revision", "Solve 5 practice problems"],
                  "study_time": "1 hour"
                }
              ]
            }

            Rules:
            1. Plan must cover the days leading up to the exam. Limit to maximum 7 days if the date is far, to keep the plan crisp and friendly.
            2. The subjects, topics, and study times must be very reasonable for a child in $classLevel standard.
            3. Response must be valid JSON, do NOT wrap in markdown code blocks.
        """.trimIndent()

        val request = GenerateContentRequest(
            contents = listOf(Content(parts = listOf(Part(text = prompt)))),
            generationConfig = GenerationConfig(responseMimeType = "application/json", temperature = 0.6f)
        )

        try {
            val response = RetrofitClient.service.generateContent(apiKey, request)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: ""
        } catch (e: Exception) {
            ""
        }
    }

    /**
     * Generates a beautiful motivational quote of the day, personalized for the student.
     */
    suspend fun generateMotivationalQuote(studentName: String): String = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isEmpty()) return@withContext "Keep shining! Focus and hard work can achieve any dream. You can do it!"

        val prompt = "Generate a short, powerful, and deeply inspiring 1-sentence motivational quote for a school student named $studentName who lives in a rural Indian community. Keep it simple, warm, related to education or dreams, and under 25 words."

        val request = GenerateContentRequest(
            contents = listOf(Content(parts = listOf(Part(text = prompt)))),
            generationConfig = GenerationConfig(temperature = 0.8f)
        )

        try {
            val response = RetrofitClient.service.generateContent(apiKey, request)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text?.replace("\"", "") 
                ?: "Believe in yourself, $studentName! Every step of learning brings you closer to your big dreams."
        } catch (e: Exception) {
            "Believe in yourself, $studentName! Every step of learning brings you closer to your big dreams."
        }
    }
}
