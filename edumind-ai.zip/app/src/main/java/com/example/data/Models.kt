package com.example.data

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class GeminiQuiz(
    val questions: List<GeminiQuestion>
)

@JsonClass(generateAdapter = true)
data class GeminiQuestion(
    val question: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String
)

@JsonClass(generateAdapter = true)
data class GeminiStudyPlan(
    val exam_name: String,
    val days: List<GeminiDayPlan>
)

@JsonClass(generateAdapter = true)
data class GeminiDayPlan(
    val day: String,
    val focus_subject: String,
    val topics: List<String>,
    val study_time: String
)

// UI specific model for tracking checkboxes
data class UIStudyPlan(
    val examName: String,
    val days: List<UIDayPlan>
)

data class UIDayPlan(
    val day: String,
    val focusSubject: String,
    val topics: List<UITopic>,
    val studyTime: String
)

data class UITopic(
    val text: String,
    val isDone: Boolean
)
