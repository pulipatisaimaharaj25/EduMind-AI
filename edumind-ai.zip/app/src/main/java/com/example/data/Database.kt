package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "students")
data class Student(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val classLevel: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "quiz_scores")
data class QuizScore(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val studentId: Int,
    val subject: String,
    val score: Int,
    val total: Int,
    val date: Long = System.currentTimeMillis()
)

@Entity(tableName = "study_plans")
data class StudyPlan(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val studentId: Int,
    val examName: String,
    val examDate: String,
    val subjects: String,
    val planJson: String // Day-by-day JSON schedule
)

@Dao
interface EduDao {
    @Query("SELECT * FROM students ORDER BY id DESC LIMIT 1")
    fun getCurrentStudent(): Flow<Student?>

    @Query("SELECT * FROM quiz_scores WHERE studentId = :studentId ORDER BY id DESC")
    fun getQuizScoresFlow(studentId: Int): Flow<List<QuizScore>>

    @Query("SELECT * FROM quiz_scores WHERE studentId = :studentId ORDER BY id DESC LIMIT 5")
    fun getLast5QuizScores(studentId: Int): Flow<List<QuizScore>>

    @Query("SELECT * FROM study_plans WHERE studentId = :studentId ORDER BY id DESC")
    fun getStudyPlansFlow(studentId: Int): Flow<List<StudyPlan>>

    @Query("SELECT * FROM study_plans WHERE studentId = :studentId ORDER BY id DESC LIMIT 1")
    fun getLatestStudyPlan(studentId: Int): Flow<StudyPlan?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudent(student: Student): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuizScore(score: QuizScore)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudyPlan(plan: StudyPlan)

    @Query("DELETE FROM students")
    suspend fun clearAllStudents()

    @Query("DELETE FROM quiz_scores")
    suspend fun clearAllQuizScores()

    @Query("DELETE FROM study_plans")
    suspend fun clearAllStudyPlans()
}

@Database(entities = [Student::class, QuizScore::class, StudyPlan::class], version = 1, exportSchema = false)
abstract class EduDatabase : RoomDatabase() {
    abstract fun eduDao(): EduDao

    companion object {
        @Volatile
        private var INSTANCE: EduDatabase? = null

        fun getDatabase(context: Context): EduDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    EduDatabase::class.java,
                    "edumind_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
