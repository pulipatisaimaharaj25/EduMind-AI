package com.example.data

import kotlinx.coroutines.flow.Flow

class EduRepository(private val eduDao: EduDao) {

    val currentStudent: Flow<Student?> = eduDao.getCurrentStudent()

    fun getQuizScores(studentId: Int): Flow<List<QuizScore>> {
        return eduDao.getQuizScoresFlow(studentId)
    }

    fun getLast5Scores(studentId: Int): Flow<List<QuizScore>> {
        return eduDao.getLast5QuizScores(studentId)
    }

    fun getStudyPlans(studentId: Int): Flow<List<StudyPlan>> {
        return eduDao.getStudyPlansFlow(studentId)
    }

    fun getLatestStudyPlan(studentId: Int): Flow<StudyPlan?> {
        return eduDao.getLatestStudyPlan(studentId)
    }

    suspend fun insertStudent(student: Student): Long {
        return eduDao.insertStudent(student)
    }

    suspend fun insertQuizScore(score: QuizScore) {
        eduDao.insertQuizScore(score)
    }

    suspend fun insertStudyPlan(plan: StudyPlan) {
        eduDao.insertStudyPlan(plan)
    }

    suspend fun clearAllData() {
        eduDao.clearAllStudents()
        eduDao.clearAllQuizScores()
        eduDao.clearAllStudyPlans()
    }
}
