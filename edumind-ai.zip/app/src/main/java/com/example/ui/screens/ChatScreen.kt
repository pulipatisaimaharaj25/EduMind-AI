package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.ChatMessage
import com.example.ui.EduMindViewModel
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun ChatScreen(
    viewModel: EduMindViewModel,
    modifier: Modifier = Modifier
) {
    val messages by viewModel.chatMessages.collectAsState()
    val isTel by viewModel.isTelugu.collectAsState()
    val currentSub by viewModel.selectedSubject.collectAsState()
    val chatLoading by viewModel.chatLoading.collectAsState()

    var questionText by remember { mutableStateOf("") }
    val subjects = listOf("Math", "Science", "English", "Social", "Computer")
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    // Auto-scroll to the bottom when a new message arrives
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DeepBlue)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp)
        ) {
            // Header with Subject Selection and Language Toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "AI Doubt Solver",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "Choose your subject below:",
                        fontSize = 12.sp,
                        color = TextMuted
                    )
                }

                // Telugu Toggle Button
                Button(
                    onClick = { viewModel.toggleLanguage() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isTel) SoftGreen else SlateDark
                    ),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.border(
                        1.dp,
                        if (isTel) Color.White else SlateBorder,
                        RoundedCornerShape(20.dp)
                    )
                ) {
                    Text(
                        text = if (isTel) "తెలుగు (Telugu) ✓" else "తెలుగులో కావాలా?",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }

            // Subject Row Selection Buttons (Large Tap Targets)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                subjects.forEach { subject ->
                    val isSelected = currentSub == subject
                    val icon = when (subject) {
                        "Math" -> "🧮"
                        "Science" -> "🔬"
                        "English" -> "📖"
                        "Social" -> "🌍"
                        else -> "💻"
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) PurplePrimary else SoftCardBg)
                            .border(
                                1.dp,
                                if (isSelected) AccentCyan else SlateBorder.copy(alpha = 0.3f),
                                RoundedCornerShape(12.dp)
                            )
                            .clickable { viewModel.setSubject(subject) }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = icon, fontSize = 20.sp)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = subject,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else TextLight
                            )
                        }
                    }
                }
            }

            // Clear chat button if messages exist
            if (messages.isNotEmpty()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(
                        onClick = { viewModel.clearChat() },
                        colors = ButtonDefaults.textButtonColors(contentColor = SoftRed)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "Clear Chat", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Clear Chat", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Chat Messages Scroll Area
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (messages.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 40.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(24.dp)
                            ) {
                                Text(text = "🤖", fontSize = 48.sp, modifier = Modifier.padding(bottom = 12.dp))
                                Text(
                                    text = "Ask any doubt in $currentSub!",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    textAlign = TextAlign.Center
                                )
                                Text(
                                    text = if (isTel) {
                                        "ఉదాహరణకు: 'కిరణజన్య సంయోగక్రియ అంటే ఏమిటి?' లేదా 'సమబాహు త్రిభుజం వైశాల్య సూత్రం ఏమిటి?'"
                                    } else {
                                        "For example: 'Explain photosynthesis' or 'What is the formula for the area of a circle?'"
                                    },
                                    fontSize = 13.sp,
                                    color = TextMuted,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(top = 6.dp),
                                    lineHeight = 18.sp
                                )
                            }
                        }
                    }
                } else {
                    items(messages) { message ->
                        ChatBubble(message)
                    }
                }

                if (chatLoading) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = SlateDark),
                                shape = RoundedCornerShape(topStart = 4.dp, topEnd = 16.dp, bottomStart = 16.dp, bottomEnd = 16.dp),
                                modifier = Modifier
                                    .widthIn(max = 280.dp)
                                    .border(1.dp, PurplePrimary.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        color = AccentCyan,
                                        strokeWidth = 2.dp
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = if (isTel) "EduMind AI ఆలోచిస్తోంది..." else "EduMind AI is thinking...",
                                        fontSize = 12.sp,
                                        color = TextLight,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Input Send Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = questionText,
                    onValueChange = { questionText = it },
                    placeholder = {
                        Text(
                            text = if (isTel) "ఇక్కడ మీ సందేహాన్ని అడగండి..." else "Ask your doubt here...",
                            color = TextMuted,
                            fontSize = 14.sp
                        )
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PurplePrimary,
                        unfocusedBorderColor = SlateBorder,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = SoftCardBg,
                        unfocusedContainerColor = SoftCardBg
                    ),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.weight(1f),
                    singleLine = false,
                    maxLines = 3
                )

                Spacer(modifier = Modifier.width(8.dp))

                // Send Icon Button (Tap Target Size 48dp)
                IconButton(
                    onClick = {
                        if (questionText.trim().isNotEmpty() && !chatLoading) {
                            viewModel.askDoubt(questionText.trim())
                            questionText = ""
                        }
                    },
                    enabled = questionText.trim().isNotEmpty() && !chatLoading,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(
                            if (questionText.trim().isNotEmpty() && !chatLoading) PurplePrimary
                            else SlateDark
                        )
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Send doubt",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ChatBubble(message: ChatMessage) {
    val isStudent = message.sender == "STUDENT"
    
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        contentAlignment = if (isStudent) Alignment.CenterEnd else Alignment.CenterStart
    ) {
        Card(
            colors = CardDefaults.cardColors(
                containerColor = if (isStudent) PurplePrimary else SlateDark
            ),
            shape = if (isStudent) {
                RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomStart = 16.dp, bottomEnd = 4.dp)
            } else {
                RoundedCornerShape(topStart = 4.dp, topEnd = 16.dp, bottomStart = 16.dp, bottomEnd = 16.dp)
            },
            modifier = Modifier
                .widthIn(max = 290.dp)
                .border(
                    width = 1.dp,
                    color = if (isStudent) AccentCyan.copy(alpha = 0.2f) else PurplePrimary.copy(alpha = 0.2f),
                    shape = if (isStudent) {
                        RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomStart = 16.dp, bottomEnd = 4.dp)
                    } else {
                        RoundedCornerShape(topStart = 4.dp, topEnd = 16.dp, bottomStart = 16.dp, bottomEnd = 16.dp)
                    }
                )
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                // Sender / Language Label
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isStudent) "You" else "EduMind AI ✨",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (isStudent) PurpleLight else AccentCyan
                    )
                    Text(
                        text = if (message.isTelugu) "తెలుగు" else "English",
                        fontSize = 9.sp,
                        color = TextMuted,
                        fontWeight = FontWeight.Bold
                    )
                }
                
                Spacer(modifier = Modifier.height(6.dp))
                
                // Explanations text
                Text(
                    text = message.text,
                    fontSize = 15.sp, // Readable for students
                    color = Color.White,
                    lineHeight = 22.sp
                )
            }
        }
    }
}
