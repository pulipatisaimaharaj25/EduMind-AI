package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.EduMindViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PlannerScreen(
    viewModel: EduMindViewModel,
    modifier: Modifier = Modifier
) {
    val step by viewModel.plannerStep.collectAsState()
    val loading by viewModel.plannerLoading.collectAsState()
    val activePlan by viewModel.activeUIPlan.collectAsState()
    val isTel by viewModel.isTelugu.collectAsState()
    val errorMsg by viewModel.plannerError.collectAsState()

    val scrollState = rememberScrollState()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DeepBlue)
    ) {
        when {
            step == "FORM" -> {
                PlannerFormView(
                    viewModel = viewModel,
                    isTel = isTel,
                    errorMsg = errorMsg,
                    scrollState = scrollState
                )
            }
            step == "PLAN" -> {
                if (loading) {
                    PlannerLoadingView(isTel = isTel)
                } else if (activePlan != null) {
                    PlannerActiveView(
                        activePlan = activePlan!!,
                        viewModel = viewModel,
                        isTel = isTel,
                        scrollState = scrollState
                    )
                } else {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Button(onClick = { viewModel.plannerStep.value = "FORM" }) {
                            Text("Create study schedule")
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PlannerFormView(
    viewModel: EduMindViewModel,
    isTel: Boolean,
    errorMsg: String?,
    scrollState: androidx.compose.foundation.ScrollState
) {
    var examName by remember { mutableStateOf("") }
    var examDate by remember { mutableStateOf("") }
    val subjectsList = listOf("Math", "Science", "English", "Social", "Computer")
    val selectedSubjects = remember { mutableStateListOf<String>() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = "AI Day-by-Day Study Planner",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            textAlign = TextAlign.Center
        )

        Text(
            text = if (isTel) {
                "మీ పరీక్ష పేరు మరియు సబ్జెక్టులను టైప్ చేయండి, AI చక్కని టైమ్‌టేబుల్ ఇస్తుంది."
            } else {
                "Input your upcoming exam details, select subjects, and get a customized daily preparation calendar."
            },
            fontSize = 13.sp,
            color = TextMuted,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 4.dp, bottom = 20.dp),
            lineHeight = 18.sp
        )

        // Planner input cards
        Card(
            colors = CardDefaults.cardColors(containerColor = SoftCardBg),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "Exam Details",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = AccentCyan,
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                // Exam Name
                OutlinedTextField(
                    value = examName,
                    onValueChange = { examName = it },
                    label = { Text("What exam are you preparing for?", color = TextLight.copy(alpha = 0.7f)) },
                    placeholder = { Text("e.g. Unit Test 1, Half-Yearly Board Exam", color = TextMuted) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PurplePrimary,
                        unfocusedBorderColor = SlateBorder,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = SlateDark.copy(alpha = 0.4f),
                        unfocusedContainerColor = SlateDark.copy(alpha = 0.2f)
                    ),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Time Left
                OutlinedTextField(
                    value = examDate,
                    onValueChange = { examDate = it },
                    label = { Text("When is the Exam / How many days left?", color = TextLight.copy(alpha = 0.7f)) },
                    placeholder = { Text("e.g. In 5 days, Next Monday", color = TextMuted) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PurplePrimary,
                        unfocusedBorderColor = SlateBorder,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = SlateDark.copy(alpha = 0.4f),
                        unfocusedContainerColor = SlateDark.copy(alpha = 0.2f)
                    ),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Subject check selector card
        Card(
            colors = CardDefaults.cardColors(containerColor = SoftCardBg),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "Select Subjects to Study:",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = AccentCyan,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    subjectsList.forEach { sub ->
                        val isSelected = selectedSubjects.contains(sub)
                        val icon = when (sub) {
                            "Math" -> "🧮 Math"
                            "Science" -> "🔬 Science"
                            "English" -> "📖 English"
                            "Social" -> "🌍 Social"
                            else -> "💻 Computer"
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(30.dp))
                                .background(if (isSelected) PurplePrimary else SlateDark)
                                .border(
                                    width = 1.dp,
                                    color = if (isSelected) AccentCyan else SlateBorder.copy(alpha = 0.4f),
                                    shape = RoundedCornerShape(30.dp)
                                )
                                .clickable {
                                    if (isSelected) selectedSubjects.remove(sub) else selectedSubjects.add(sub)
                                }
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = icon,
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        if (errorMsg != null) {
            Text(
                text = errorMsg,
                color = SoftRed,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 12.dp)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Submit Button
        Button(
            onClick = {
                viewModel.generatePlan(examName.trim(), examDate.trim(), selectedSubjects.toList())
            },
            colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) {
            Text(
                text = if (isTel) "AI తో ప్లాన్ తయారు చెయ్యి 📅" else "Generate Study Planner 🚀",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }

        Spacer(modifier = Modifier.height(30.dp))
    }
}

@Composable
fun PlannerLoadingView(isTel: Boolean) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = AccentCyan, strokeWidth = 4.dp, modifier = Modifier.size(48.dp))
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = if (isTel) "మీ పరీక్షల ప్లాన్ తయారు చేయబడుతోంది..." else "Creating your day-by-day study schedule...",
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 24.dp)
            )
            Text(
                text = if (isTel) "ప్రతి రోజూ ప్లాన్ ప్రకారం చదివితే మంచి మార్కులు వస్తాయి!" else "Organized study yields excellent grades!",
                color = TextMuted,
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 6.dp)
            )
        }
    }
}

@Composable
fun PlannerActiveView(
    activePlan: com.example.data.UIStudyPlan,
    viewModel: EduMindViewModel,
    isTel: Boolean,
    scrollState: androidx.compose.foundation.ScrollState
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        horizontalAlignment = Alignment.Start
    ) {
        // Back to form button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { viewModel.plannerStep.value = "FORM" },
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(SlateDark)
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back to Form", tint = Color.White)
            }
            Text(
                text = "My Study Plan",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = AccentCyan
            )
            Box(modifier = Modifier.size(48.dp)) // Equalizer spacer
        }

        Text(
            text = "📅 ${activePlan.examName}",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            modifier = Modifier.padding(bottom = 4.dp)
        )

        Text(
            text = "Follow this custom calendar schedule. Mark topics as checked once completed!",
            fontSize = 12.sp,
            color = TextMuted,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Day-by-Day Cards list
        activePlan.days.forEachIndexed { dIdx, day ->
            val allTopicsDone = day.topics.all { it.isDone }

            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (allTopicsDone) SlateDark.copy(alpha = 0.5f) else SoftCardBg
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .border(
                        width = 1.dp,
                        color = if (allTopicsDone) SoftGreen.copy(alpha = 0.4f) else PurplePrimary.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(16.dp)
                    )
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = day.day,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White
                                )
                                if (allTopicsDone) {
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(SoftGreen.copy(alpha = 0.15f))
                                            .padding(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Text(text = "Completed ✓", fontSize = 9.sp, color = SoftGreen, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                            Text(
                                text = "Focus: ${day.focusSubject}",
                                fontSize = 12.sp,
                                color = AccentCyan,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(PurplePrimary.copy(alpha = 0.2f))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "⏳ ${day.studyTime}",
                                fontSize = 11.sp,
                                color = PurpleLight,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Divider(
                        color = Color.White.copy(alpha = 0.08f),
                        modifier = Modifier.padding(vertical = 12.dp)
                    )

                    // Topic checkboxes
                    day.topics.forEachIndexed { tIdx, topic ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.toggleTopicDone(dIdx, tIdx)
                                }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = topic.isDone,
                                onCheckedChange = {
                                    viewModel.toggleTopicDone(dIdx, tIdx)
                                },
                                colors = CheckboxDefaults.colors(
                                    checkedColor = SoftGreen,
                                    uncheckedColor = SlateBorder
                                )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = topic.text,
                                fontSize = 13.sp,
                                color = if (topic.isDone) TextMuted else Color.White,
                                style = if (topic.isDone) MaterialTheme.typography.bodyMedium.copy(
                                    textDecoration = androidx.compose.ui.text.style.TextDecoration.LineThrough
                                ) else MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(30.dp))
    }
}
