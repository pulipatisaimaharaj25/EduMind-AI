package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val EduMindColorScheme = darkColorScheme(
    primary = PurplePrimary,
    onPrimary = Color.White,
    primaryContainer = PurpleDark,
    onPrimaryContainer = PurpleLight,
    secondary = AccentCyan,
    onSecondary = Color.Black,
    secondaryContainer = SlateDark,
    onSecondaryContainer = TextLight,
    background = DeepBlue,
    onBackground = TextLight,
    surface = SoftCardBg,
    onSurface = TextLight,
    surfaceVariant = SlateDark,
    onSurfaceVariant = TextMuted,
    error = SoftRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = EduMindColorScheme,
        typography = Typography,
        content = content
    )
}
