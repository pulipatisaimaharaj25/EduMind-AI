package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Theme Colors
val DeepBlue = Color(0xFF1A1A2E)
val DeepBlueDark = Color(0xFF111124)
val PurplePrimary = Color(0xFF7C3AED)
val PurpleDark = Color(0xFF5B21B6)
val PurpleLight = Color(0xFFDDD6FE)
val AccentCyan = Color(0xFF06B6D4)
val AccentYellow = Color(0xFFFBBF24)

// Support UI Colors
val SlateDark = Color(0xFF24243E)
val SlateLight = Color(0xFFF8FAFC)
val SlateBorder = Color(0xFF475569)
val TextLight = Color(0xFFF1F5F9)
val TextDark = Color(0xFF0F172A)
val TextMuted = Color(0xFF94A3B8)

val SoftGreen = Color(0xFF10B981)
val SoftRed = Color(0xFFEF4444)
val SoftCardBg = Color(0xFF1E1E38)
