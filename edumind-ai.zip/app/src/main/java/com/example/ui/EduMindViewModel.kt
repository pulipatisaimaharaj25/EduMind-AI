package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class ChatMessage(
    val sender: String, // "STUDENT" or "AI"
    val text: String,
    val subject: String,
    val isTelugu: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

class EduMindViewModel(application: Application) : AndroidViewModel(application) {

    private val database = EduDatabase.getDatabase(application)
    private val repository = EduRepository(database.eduDao())

    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
    private val studyPlanAdapter = moshi.adapter(GeminiStudyPlan::class.java)
    private val quizAdapter = moshi.adapter(GeminiQuiz::class.java)

    // --- Core States ---
    val currentStudent: StateFlow<Student?> = repository.currentStudent
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val isTelugu = MutableStateFlow(false)

    // Dynamic motivational quote
    private val _motivationalQuote = MutableStateFlow("Knowledge is a treasure that will follow its owner everywhere.")
    val motivationalQuote: StateFlow<String> = _motivationalQuote.asStateFlow()

    // --- Feature 1: AI Doubt Solver Chat State ---
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    val selectedSubject = MutableStateFlow("Math")
    val chatLoading = MutableStateFlow(false)

    // --- Feature 2: Quiz State ---
    val quizSubject = MutableStateFlow("Math")
    val quizDifficulty = MutableStateFlow("Medium")
    val quizLoading = MutableStateFlow(false)
    val quizStep = MutableStateFlow("CONFIG") // "CONFIG", "ACTIVE", "RESULT"
    val quizError = MutableStateFlow<String?>(null)

    private val _quizQuestions = MutableStateFlow<List<GeminiQuestion>>(emptyList())
    val quizQuestions: StateFlow<List<GeminiQuestion>> = _quizQuestions.asStateFlow()

    val currentQuestionIndex = MutableStateFlow(0)
    val selectedOptionIndex = MutableStateFlow<Int?>(null)
    val quizAnswers = MutableStateFlow<List<Int?>>(emptyList()) // Record student choices
    val quizScore = MutableStateFlow(0)

    val quizHistory = currentStudent.flatMapLatest { student ->
        if (student != null) {
            repository.getLast5Scores(student.id)
        } else {
            flowOf(emptyList())
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Feature 3: Planner State ---
    val plannerLoading = MutableStateFlow(false)
    val plannerStep = MutableStateFlow("FORM") // "FORM", "PLAN"
    val plannerError = MutableStateFlow<String?>(null)

    // Track active UI study plan
    private val _activeUIPlan = MutableStateFlow<UIStudyPlan?>(null)
    val activeUIPlan: StateFlow<UIStudyPlan?> = _activeUIPlan.asStateFlow()

    init {
        // Automatically fetch motivational quote when student logs in
        viewModelScope.launch {
            currentStudent.collect { student ->
                if (student != null) {
                    _motivationalQuote.value = GeminiService.generateMotivationalQuote(student.name)
                }
            }
        }

        // Automatically load latest study plan from DB and parse it
        viewModelScope.launch {
            currentStudent.collectLatest { student ->
                if (student != null) {
                    repository.getLatestStudyPlan(student.id).collect { plan ->
                        if (plan != null) {
                            try {
                                val geminiPlan = studyPlanAdapter.fromJson(plan.planJson)
                                if (geminiPlan != null) {
                                    // Parse to UI plan with checkboxes (all initially unchecked)
                                    // But wait! We need to make sure we don't overwrite if the user already has state saved
                                    // Our planJson contains the checkboxes state if we store it as UIStudyPlan!
                                    // Let's store the raw JSON. Since we want to persist checked states, we can store UIStudyPlan instead, or just parse a JSON that has status.
                                    // Let's parse and persist the done state.
                                    _activeUIPlan.value = parseSavedPlan(plan.planJson)
                                }
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        } else {
                            _activeUIPlan.value = null
                        }
                    }
                }
            }
        }
    }

    // --- Actions ---

    fun toggleLanguage() {
        isTelugu.value = !isTelugu.value
    }

    fun setSubject(subject: String) {
        selectedSubject.value = subject
    }

    fun registerStudent(name: String, classLevel: String) {
        viewModelScope.launch {
            repository.insertStudent(Student(name = name, classLevel = classLevel))
        }
    }

    fun clearStudentSession() {
        viewModelScope.launch {
            repository.clearAllData()
            _chatMessages.value = emptyList()
            _activeUIPlan.value = null
            plannerStep.value = "FORM"
            quizStep.value = "CONFIG"
        }
    }

    // --- Feature 1: Doubt Solver Logic ---
    fun askDoubt(question: String) {
        val student = currentStudent.value ?: return
        val currentSub = selectedSubject.value
        val isTel = isTelugu.value

        // Add user question to chat
        val userMsg = ChatMessage(sender = "STUDENT", text = question, subject = currentSub, isTelugu = isTel)
        _chatMessages.value = _chatMessages.value + userMsg

        chatLoading.value = true
        viewModelScope.launch {
            val responseText = GeminiService.solveDoubt(
                subject = currentSub,
                question = question,
                classLevel = student.classLevel,
                isTelugu = isTel
            )
            val aiMsg = ChatMessage(sender = "AI", text = responseText, subject = currentSub, isTelugu = isTel)
            _chatMessages.value = _chatMessages.value + aiMsg
            chatLoading.value = false
        }
    }

    fun clearChat() {
        _chatMessages.value = emptyList()
    }

    // --- Feature 2: Quiz Logic ---
    fun startQuizGeneration() {
        val student = currentStudent.value ?: return
        val subject = quizSubject.value
        val difficulty = quizDifficulty.value
        val isTel = isTelugu.value

        quizLoading.value = true
        quizError.value = null
        quizStep.value = "ACTIVE"
        currentQuestionIndex.value = 0
        selectedOptionIndex.value = null
        quizScore.value = 0

        viewModelScope.launch {
            val jsonString = GeminiService.generateQuiz(subject, student.classLevel, difficulty, isTel)
            if (jsonString.isNotEmpty()) {
                try {
                    val quiz = quizAdapter.fromJson(jsonString)
                    if (quiz != null && quiz.questions.isNotEmpty()) {
                        _quizQuestions.value = quiz.questions
                        quizAnswers.value = List(quiz.questions.size) { null }
                        quizLoading.value = false
                        return@launch
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            // If failed, use a local fallback quiz to guarantee seamless offline/error-free demo
            val fallback = getFallbackQuiz(subject, student.classLevel, isTel)
            _quizQuestions.value = fallback.questions
            quizAnswers.value = List(fallback.questions.size) { null }
            quizLoading.value = false
        }
    }

    fun selectQuizOption(optionIndex: Int) {
        if (selectedOptionIndex.value != null) return // Already answered this question
        selectedOptionIndex.value = optionIndex

        val currentIndex = currentQuestionIndex.value
        val questions = _quizQuestions.value
        if (currentIndex < questions.size) {
            val correct = questions[currentIndex].correctIndex == optionIndex
            if (correct) {
                quizScore.value += 1
            }

            // Record answer
            val updatedAnswers = quizAnswers.value.toMutableList()
            updatedAnswers[currentIndex] = optionIndex
            quizAnswers.value = updatedAnswers
        }
    }

    fun nextQuizQuestion() {
        val nextIdx = currentQuestionIndex.value + 1
        if (nextIdx < _quizQuestions.value.size) {
            currentQuestionIndex.value = nextIdx
            selectedOptionIndex.value = null
        } else {
            // End of Quiz, Save score
            saveQuizResult()
            quizStep.value = "RESULT"
        }
    }

    private fun saveQuizResult() {
        val student = currentStudent.value ?: return
        viewModelScope.launch {
            repository.insertQuizScore(
                QuizScore(
                    studentId = student.id,
                    subject = quizSubject.value,
                    score = quizScore.value,
                    total = _quizQuestions.value.size
                )
            )
        }
    }

    fun restartQuiz() {
        quizStep.value = "CONFIG"
        _quizQuestions.value = emptyList()
    }

    // --- Feature 3: Study Planner Logic ---
    fun generatePlan(examName: String, examDate: String, selectedSubjects: List<String>) {
        val student = currentStudent.value ?: return
        if (examName.isEmpty() || examDate.isEmpty() || selectedSubjects.isEmpty()) {
            plannerError.value = "Please fill in all fields!"
            return
        }

        plannerLoading.value = true
        plannerError.value = null
        plannerStep.value = "PLAN"

        viewModelScope.launch {
            val jsonString = GeminiService.generateStudyPlan(examName, examDate, selectedSubjects, student.classLevel)
            if (jsonString.isNotEmpty()) {
                try {
                    val geminiPlan = studyPlanAdapter.fromJson(jsonString)
                    if (geminiPlan != null) {
                        val uiPlan = UIStudyPlan(
                            examName = geminiPlan.exam_name,
                            days = geminiPlan.days.map { day ->
                                UIDayPlan(
                                    day = day.day,
                                    focusSubject = day.focus_subject,
                                    topics = day.topics.map { UITopic(text = it, isDone = false) },
                                    studyTime = day.study_time
                                )
                            }
                        )
                        _activeUIPlan.value = uiPlan
                        // Save serialized UIStudyPlan (with done states)
                        saveUIStudyPlanToDB(uiPlan)
                        plannerLoading.value = false
                        return@launch
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            // Fallback Plan for demo stability
            val fallbackUIPlan = getFallbackStudyPlan(examName, examDate, selectedSubjects)
            _activeUIPlan.value = fallbackUIPlan
            saveUIStudyPlanToDB(fallbackUIPlan)
            plannerLoading.value = false
        }
    }

    fun toggleTopicDone(dayIndex: Int, topicIndex: Int) {
        val currentUIPlan = _activeUIPlan.value ?: return
        val updatedDays = currentUIPlan.days.mapIndexed { dIdx, day ->
            if (dIdx == dayIndex) {
                val updatedTopics = day.topics.mapIndexed { tIdx, topic ->
                    if (tIdx == topicIndex) {
                        topic.copy(isDone = !topic.isDone)
                    } else {
                        topic
                    }
                }
                day.copy(topics = updatedTopics)
            } else {
                day
            }
        }
        val updatedPlan = currentUIPlan.copy(days = updatedDays)
        _activeUIPlan.value = updatedPlan
        saveUIStudyPlanToDB(updatedPlan)
    }

    private fun saveUIStudyPlanToDB(uiPlan: UIStudyPlan) {
        val student = currentStudent.value ?: return
        viewModelScope.launch {
            // Serialize UIStudyPlan containing done states
            val json = serializeUIPlan(uiPlan)
            repository.insertStudyPlan(
                StudyPlan(
                    studentId = student.id,
                    examName = uiPlan.examName,
                    examDate = "",
                    subjects = uiPlan.days.map { it.focusSubject }.distinct().joinToString(", "),
                    planJson = json
                )
            )
        }
    }

    // --- Custom JSON SerDe Helpers ---

    private fun serializeUIPlan(uiPlan: UIStudyPlan): String {
        // Since we want to save checkboxes, convert UIStudyPlan back to a simple json
        // We can do this simply by creating helper maps or using a basic custom builder
        return try {
            val list = uiPlan.days.map { day ->
                mapOf(
                    "day" to day.day,
                    "focusSubject" to day.focusSubject,
                    "studyTime" to day.studyTime,
                    "topics" to day.topics.map { mapOf("text" to it.text, "isDone" to it.isDone) }
                )
            }
            val mainMap = mapOf(
                "examName" to uiPlan.examName,
                "days" to list
            )
            val adapter = moshi.adapter(Any::class.java)
            adapter.toJson(mainMap)
        } catch (e: Exception) {
            ""
        }
    }

    @Suppress("UNCHECKED_CAST")
    private fun parseSavedPlan(json: String): UIStudyPlan? {
        return try {
            val adapter = moshi.adapter(Map::class.java)
            val map = adapter.fromJson(json) as? Map<String, Any> ?: return null
            val examName = map["examName"] as? String ?: "My Exam"
            val daysList = map["days"] as? List<Map<String, Any>> ?: return null
            
            val days = daysList.map { dayMap ->
                val day = dayMap["day"] as? String ?: ""
                val focusSubject = dayMap["focusSubject"] as? String ?: ""
                val studyTime = dayMap["studyTime"] as? String ?: ""
                val topicsList = dayMap["topics"] as? List<Map<String, Any>> ?: emptyList()
                
                val topics = topicsList.map { topicMap ->
                    UITopic(
                        text = topicMap["text"] as? String ?: "",
                        isDone = topicMap["isDone"] as? Boolean ?: false
                    )
                }
                UIDayPlan(day, focusSubject, topics, studyTime)
            }
            UIStudyPlan(examName, days)
        } catch (e: Exception) {
            // Fallback try standard GeminiStudyPlan format
            try {
                val plan = studyPlanAdapter.fromJson(json) ?: return null
                UIStudyPlan(
                    examName = plan.exam_name,
                    days = plan.days.map { day ->
                        UIDayPlan(
                            day = day.day,
                            focusSubject = day.focus_subject,
                            topics = day.topics.map { UITopic(it, false) },
                            studyTime = day.study_time
                        )
                    }
                )
            } catch (ex: Exception) {
                null
            }
        }
    }

    // --- Local Fallback Data for Stability ---

    private fun getFallbackQuiz(subject: String, classLevel: String, isTel: Boolean): GeminiQuiz {
        return if (isTel) {
            GeminiQuiz(
                questions = listOf(
                    GeminiQuestion(
                        question = "కింది వాటిలో ఏది సహజ సంఖ్య?",
                        options = listOf("A) -5", "B) 0", "C) 5", "D) 1/2"),
                        correctIndex = 2,
                        explanation = "సహజ సంఖ్యలు 1 నుండి ప్రారంభమవుతాయి (1, 2, 3, 4, 5...)."
                    ),
                    GeminiQuestion(
                        question = "సూర్యుడు ఏ దిక్కున ఉదయిస్తాడు?",
                        options = listOf("A) పడమర", "B) తూర్పు", "C) ఉత్తరం", "D) దక్షిణం"),
                        correctIndex = 1,
                        explanation = "భూమి పడమర నుండి తూర్పుకు తిరుగుతుంది కాబట్టి సూర్యుడు తూర్పున ఉదయిస్తాడు."
                    ),
                    GeminiQuestion(
                        question = "కింది వాటిలో ఏది ద్రవ రూపంలో ఉండే లోహం?",
                        options = listOf("A) ఇనుము", "B) పాదరసం (Mercury)", "C) రాగి", "D) బంగారం"),
                        correctIndex = 1,
                        explanation = "సాధారణ ఉష్ణోగ్రత వద్ద పాదరసం ద్రవ రూపంలో ఉంటుంది."
                    ),
                    GeminiQuestion(
                        question = "మొక్కలు ఆహారాన్ని తయారుచేసే ప్రక్రియను ఏమంటారు?",
                        options = listOf("A) శ్వాసక్రియ", "B) కిరణజన్య సంయోగక్రియ (Photosynthesis)", "C) జీర్ణక్రియ", "D) ఆవిరిపోవడం"),
                        correctIndex = 1,
                        explanation = "ఆకుపచ్చని మొక్కలు సూర్యరశ్మి సహాయంతో కిరణజన్య సంయోగక్రియ ద్వారా ఆహారాన్ని తయారుచేస్తాయి."
                    ),
                    GeminiQuestion(
                        question = "కంప్యూటర్ మెదడు అని దేనిని పిలుస్తారు?",
                        options = listOf("A) మౌస్", "B) కీబోర్డ్", "C) CPU", "D) మానిటర్"),
                        correctIndex = 2,
                        explanation = "CPU (Central Processing Unit) కంప్యూటర్ యొక్క అన్ని పనులను నియంత్రిస్తుంది."
                    )
                )
            )
        } else {
            GeminiQuiz(
                questions = listOf(
                    GeminiQuestion(
                        question = "What is the primary gas found in the Earth's atmosphere?",
                        options = listOf("A) Oxygen", "B) Carbon Dioxide", "C) Nitrogen", "D) Hydrogen"),
                        correctIndex = 2,
                        explanation = "Nitrogen makes up about 78% of the Earth's atmosphere."
                    ),
                    GeminiQuestion(
                        question = "Which of the following is an even prime number?",
                        options = listOf("A) 1", "B) 2", "C) 3", "D) 5"),
                        correctIndex = 1,
                        explanation = "2 is the only prime number that is even."
                    ),
                    GeminiQuestion(
                        question = "What is the capital of India?",
                        options = listOf("A) Mumbai", "B) Kolkata", "C) New Delhi", "D) Chennai"),
                        correctIndex = 2,
                        explanation = "New Delhi is the official capital of India."
                    ),
                    GeminiQuestion(
                        question = "Which organ pumps blood in the human body?",
                        options = listOf("A) Lungs", "B) Brain", "C) Heart", "D) Kidneys"),
                        correctIndex = 2,
                        explanation = "The heart pumps oxygenated and deoxygenated blood to the body."
                    ),
                    GeminiQuestion(
                        question = "Which of these is an input device for a computer?",
                        options = listOf("A) Monitor", "B) Printer", "C) Keyboard", "D) Speakers"),
                        correctIndex = 2,
                        explanation = "A keyboard allows you to input text commands into the computer."
                    )
                )
            )
        }
    }

    private fun getFallbackStudyPlan(examName: String, examDate: String, subjects: List<String>): UIStudyPlan {
        val days = listOf("Day 1", "Day 2", "Day 3", "Day 4", "Day 5")
        val generatedDays = days.mapIndexed { index, day ->
            val sub = subjects[index % subjects.size]
            UIDayPlan(
                day = day,
                focusSubject = sub,
                topics = listOf(
                    UITopic("Read Chapter ${index + 1} thoroughly", false),
                    UITopic("Solve previous year questions on $sub", false),
                    UITopic("Create a short formula / terms revision chart", false)
                ),
                studyTime = "1.5 hours"
            )
        }
        return UIStudyPlan(examName, generatedDays)
    }
}
