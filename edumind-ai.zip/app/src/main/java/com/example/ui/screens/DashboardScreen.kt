package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.EduMindViewModel
import com.example.ui.theme.*

@Composable
fun DashboardScreen(
    viewModel: EduMindViewModel,
    modifier: Modifier = Modifier,
    onCreatePlanClick: () -> Unit
) {
    val student by viewModel.currentStudent.collectAsState()
    val quote by viewModel.motivationalQuote.collectAsState()
    val quizHistory by viewModel.quizHistory.collectAsState()
    val activePlan by viewModel.activeUIPlan.collectAsState()
    
    val scrollState = rememberScrollState()

    // Derived: Today's study tasks (let's say we show the first uncompleted day's tasks, or Day 1 tasks by default)
    val todayDayPlan = activePlan?.days?.firstOrNull { day ->
        day.topics.any { !it.isDone }
    } ?: activePlan?.days?.firstOrNull()

    val todayDayIndex = activePlan?.days?.indexOf(todayDayPlan) ?: -1

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DeepBlue)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(10.dp))

            // Welcome Back Header
            student?.let { stud ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = SoftCardBg),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, PurplePrimary.copy(alpha = 0.3f), RoundedCornerShape(20.dp))
                ) {
                    Row(
                        modifier = Modifier.padding(20.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Brush.linearGradient(listOf(PurplePrimary, AccentCyan))),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = stud.name.firstOrNull()?.uppercase() ?: "S",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        Column {
                            Text(
                                text = "Namaste, ${stud.name}! 👋",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "Class ${stud.classLevel} Student",
                                fontSize = 13.sp,
                                color = AccentCyan,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Daily Motivational Quote (AI Generated)
            Card(
                colors = CardDefaults.cardColors(containerColor = SlateDark),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, AccentCyan.copy(alpha = 0.2f), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(bottom = 8.dp)
                    ) {
                        Text(text = "🌟", fontSize = 18.sp, modifier = Modifier.padding(end = 8.dp))
                        Text(
                            text = "AI Motivation of the Day",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = AccentCyan,
                            letterSpacing = 1.sp
                        )
                    }
                    Text(
                        text = "\"$quote\"",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = TextLight,
                        lineHeight = 20.sp,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Subject Completion Progress Bars
            Card(
                colors = CardDefaults.cardColors(containerColor = SoftCardBg),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(20.dp))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Your Subjects Progress",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    // Hardcoded standard subject trackers
                    SubjectProgressBar(subject = "🧮 Mathematics", progress = 0.65f, progressStr = "65%")
                    Spacer(modifier = Modifier.height(10.dp))
                    SubjectProgressBar(subject = "🔬 Science & Tech", progress = 0.80f, progressStr = "80%")
                    Spacer(modifier = Modifier.height(10.dp))
                    SubjectProgressBar(subject = "📖 English Grammar", progress = 0.45f, progressStr = "45%")
                    Spacer(modifier = Modifier.height(10.dp))
                    SubjectProgressBar(subject = "🌍 Social Studies", progress = 0.50f, progressStr = "50%")
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Today's Study Tasks (Plan Integration)
            Text(
                text = "📚 Today's Study Schedule",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                textAlign = TextAlign.Start
            )

            if (activePlan == null) {
                // No study plan empty state
                Card(
                    colors = CardDefaults.cardColors(containerColor = SlateDark.copy(alpha = 0.6f)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, SlateBorder.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
                        .clickable { onCreatePlanClick() }
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "📅", fontSize = 36.sp, modifier = Modifier.padding(bottom = 8.dp))
                        Text(
                            text = "No active Study Timetable",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "Rural students who plan their exams score 40% higher! Tap here to let our AI build your daily study timeline.",
                            fontSize = 12.sp,
                            color = TextMuted,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                        )
                        Button(
                            onClick = onCreatePlanClick,
                            colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Create Study Plan 🚀", color = Color.White, fontSize = 13.sp)
                        }
                    }
                }
            } else {
                // Active day plan tasks checklist
                todayDayPlan?.let { dayPlan ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SlateDark),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, PurplePrimary.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "${activePlan?.examName} - ${dayPlan.day}",
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "Focus Subject: ${dayPlan.focusSubject}",
                                        fontSize = 12.sp,
                                        color = AccentCyan,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(PurplePrimary.copy(alpha = 0.2f))
                                        .padding(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = "⏳ ${dayPlan.studyTime}",
                                        fontSize = 11.sp,
                                        color = PurpleLight,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Divider(
                                color = Color.White.copy(alpha = 0.1f),
                                modifier = Modifier.padding(vertical = 12.dp)
                            )

                            // Show tasks as checklist
                            dayPlan.topics.forEachIndexed { tIdx, topic ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            viewModel.toggleTopicDone(todayDayIndex, tIdx)
                                        }
                                        .padding(vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Checkbox(
                                        checked = topic.isDone,
                                        onCheckedChange = {
                                            viewModel.toggleTopicDone(todayDayIndex, tIdx)
                                        },
                                        colors = CheckboxDefaults.colors(
                                            checkedColor = SoftGreen,
                                            uncheckedColor = SlateBorder
                                        )
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = topic.text,
                                        fontSize = 13.sp,
                                        color = if (topic.isDone) TextMuted else Color.White,
                                        style = if (topic.isDone) MaterialTheme.typography.bodyMedium.copy(
                                            textDecoration = androidx.compose.ui.text.style.TextDecoration.LineThrough
                                        ) else MaterialTheme.typography.bodyMedium
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Quiz Scores History Section
            Text(
                text = "📊 Recent Quiz History",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                textAlign = TextAlign.Start
            )

            if (quizHistory.isEmpty()) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SlateDark.copy(alpha = 0.4f)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                ) {
                    Box(
                        modifier = Modifier.padding(20.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No Quizzes attempted yet. Go to the Quiz tab to generate an interactive exam!",
                            fontSize = 12.sp,
                            color = TextMuted,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    quizHistory.forEach { score ->
                        val isExcellent = score.score >= 4
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SoftCardBg),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.border(
                                1.dp,
                                if (isExcellent) SoftGreen.copy(alpha = 0.3f) else Color.White.copy(alpha = 0.05f),
                                RoundedCornerShape(12.dp)
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = when (score.subject) {
                                            "Math" -> "🧮"
                                            "Science" -> "🔬"
                                            "English" -> "📖"
                                            "Social" -> "🌍"
                                            else -> "💻"
                                        },
                                        fontSize = 18.sp,
                                        modifier = Modifier.padding(end = 12.dp)
                                    )
                                    Column {
                                        Text(
                                            text = score.subject,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                        Text(
                                            text = "Attempted: ${java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.getDefault()).format(score.date)}",
                                            fontSize = 11.sp,
                                            color = TextMuted
                                        )
                                    }
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "${score.score} / ${score.total}",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (isExcellent) SoftGreen else AccentYellow,
                                        modifier = Modifier.padding(end = 8.dp)
                                    )
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(
                                                if (isExcellent) SoftGreen.copy(alpha = 0.15f)
                                                else AccentYellow.copy(alpha = 0.15f)
                                            )
                                            .padding(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = if (isExcellent) "Passed" else "Review",
                                            fontSize = 9.sp,
                                            color = if (isExcellent) SoftGreen else AccentYellow,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Clear data/Reset profile option
            TextButton(
                onClick = { viewModel.clearStudentSession() },
                colors = ButtonDefaults.textButtonColors(contentColor = SoftRed.copy(alpha = 0.8f))
            ) {
                Icon(Icons.Default.Refresh, contentDescription = "Reset Profile", modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Reset Student Profile & Clear Progress", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}

@Composable
fun SubjectProgressBar(
    subject: String,
    progress: Float,
    progressStr: String
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = subject, fontSize = 13.sp, color = TextLight, fontWeight = FontWeight.Medium)
            Text(text = progressStr, fontSize = 12.sp, color = AccentCyan, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { progress },
            color = PurplePrimary,
            trackColor = SlateBorder.copy(alpha = 0.4f),
            strokeCap = androidx.compose.ui.graphics.StrokeCap.Round,
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp))
        )
    }
}
