package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.EduMindViewModel
import com.example.ui.theme.*

@Composable
fun QuizScreen(
    viewModel: EduMindViewModel,
    modifier: Modifier = Modifier
) {
    val step by viewModel.quizStep.collectAsState()
    val loading by viewModel.quizLoading.collectAsState()
    val questions by viewModel.quizQuestions.collectAsState()
    val currentIdx by viewModel.currentQuestionIndex.collectAsState()
    val selectedOpt by viewModel.selectedOptionIndex.collectAsState()
    val score by viewModel.quizScore.collectAsState()
    val subject by viewModel.quizSubject.collectAsState()
    val difficulty by viewModel.quizDifficulty.collectAsState()
    val isTel by viewModel.isTelugu.collectAsState()

    val scrollState = rememberScrollState()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DeepBlue)
    ) {
        when (step) {
            "CONFIG" -> {
                QuizConfigView(
                    viewModel = viewModel,
                    subject = subject,
                    difficulty = difficulty,
                    isTel = isTel,
                    scrollState = scrollState
                )
            }
            "ACTIVE" -> {
                if (loading) {
                    QuizLoadingView(isTel = isTel)
                } else if (questions.isNotEmpty() && currentIdx < questions.size) {
                    QuizActiveView(
                        questions = questions,
                        currentIdx = currentIdx,
                        selectedOpt = selectedOpt,
                        score = score,
                        isTel = isTel,
                        viewModel = viewModel,
                        scrollState = scrollState
                    )
                } else {
                    // Fallback configuration if questions list is empty or invalid
                    Button(
                        onClick = { viewModel.restartQuiz() },
                        modifier = Modifier.align(Alignment.Center)
                    ) {
                        Text("Reset Quiz")
                    }
                }
            }
            "RESULT" -> {
                QuizResultView(
                    score = score,
                    total = questions.size,
                    isTel = isTel,
                    viewModel = viewModel,
                    scrollState = scrollState
                )
            }
        }
    }
}

@Composable
fun QuizConfigView(
    viewModel: EduMindViewModel,
    subject: String,
    difficulty: String,
    isTel: Boolean,
    scrollState: androidx.compose.foundation.ScrollState
) {
    val subjects = listOf("Math", "Science", "English", "Social", "Computer")
    val difficulties = listOf("Easy", "Medium", "Hard")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = "Personalized Quiz Generator",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            textAlign = TextAlign.Center
        )

        Text(
            text = if (isTel) {
                "మీ తరగతి ఆధారంగా AI 5 MCQ ప్రశ్నలను తయారు చేస్తుంది."
            } else {
                "Select a subject and difficulty. Our AI will instantly create 5 customized MCQ questions for you."
            },
            fontSize = 13.sp,
            color = TextMuted,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 4.dp, bottom = 20.dp),
            lineHeight = 18.sp
        )

        // Subject selector cards
        Card(
            colors = CardDefaults.cardColors(containerColor = SoftCardBg),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "1. Select Subject:",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = AccentCyan,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                subjects.forEach { sub ->
                    val isSelected = subject == sub
                    val emoji = when (sub) {
                        "Math" -> "🧮 Mathematics"
                        "Science" -> "🔬 Science & Tech"
                        "English" -> "📖 English Language"
                        "Social" -> "🌍 Social Studies"
                        else -> "💻 Computer Literacy"
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) PurplePrimary else SlateDark)
                            .border(1.dp, if (isSelected) AccentCyan else Color.Transparent, RoundedCornerShape(10.dp))
                            .clickable { viewModel.quizSubject.value = sub }
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = isSelected,
                            onClick = { viewModel.quizSubject.value = sub },
                            colors = RadioButtonDefaults.colors(selectedColor = Color.White)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = emoji,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Difficulty selector row
        Card(
            colors = CardDefaults.cardColors(containerColor = SoftCardBg),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "2. Select Difficulty Level:",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = AccentCyan,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    difficulties.forEach { diff ->
                        val isSelected = difficulty == diff
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) PurplePrimary else SlateDark)
                                .border(1.dp, if (isSelected) AccentCyan else SlateBorder.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
                                .clickable { viewModel.quizDifficulty.value = diff }
                                .padding(vertical = 12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = diff,
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Start button
        Button(
            onClick = { viewModel.startQuizGeneration() },
            colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
        ) {
            Text(
                text = if (isTel) "రైట్, క్విజ్ ప్రారంభించు! 🚀" else "Generate 5 MCQ Quiz 🚀",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }

        Spacer(modifier = Modifier.height(30.dp))
    }
}

@Composable
fun QuizLoadingView(isTel: Boolean) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = AccentCyan, strokeWidth = 4.dp, modifier = Modifier.size(48.dp))
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = if (isTel) "మీ కోసం ప్రత్యేక క్విజ్ తయారు చేయబడుతోంది..." else "Gemini AI is generating your Quiz...",
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 24.dp)
            )
            Text(
                text = if (isTel) "దయచేసి కొన్ని సెకన్లు వేచి ఉండండి." else "This may take a few seconds.",
                color = TextMuted,
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}

@Composable
fun QuizActiveView(
    questions: List<com.example.data.GeminiQuestion>,
    currentIdx: Int,
    selectedOpt: Int?,
    score: Int,
    isTel: Boolean,
    viewModel: EduMindViewModel,
    scrollState: androidx.compose.foundation.ScrollState
) {
    val question = questions[currentIdx]
    val answered = selectedOpt != null

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        horizontalAlignment = Alignment.Start
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        // Score and progress indicator
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Question ${currentIdx + 1} of ${questions.size}",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = AccentCyan
            )
            Text(
                text = "Score: $score / ${questions.size}",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = SoftGreen
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Progress line bar
        LinearProgressIndicator(
            progress = { (currentIdx + 1) / questions.size.toFloat() },
            color = PurplePrimary,
            trackColor = SlateBorder.copy(alpha = 0.3f),
            strokeCap = androidx.compose.ui.graphics.StrokeCap.Round,
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp))
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Question Card
        Card(
            colors = CardDefaults.cardColors(containerColor = SoftCardBg),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, PurplePrimary.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = question.question,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    lineHeight = 24.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 4 Options Buttons
        question.options.forEachIndexed { optIdx, optionText ->
            val isSelected = selectedOpt == optIdx
            val isCorrectOpt = question.correctIndex == optIdx

            val cardColor = when {
                answered && isCorrectOpt -> SoftGreen.copy(alpha = 0.15f)
                answered && isSelected && !isCorrectOpt -> SoftRed.copy(alpha = 0.15f)
                isSelected -> PurplePrimary.copy(alpha = 0.3f)
                else -> SlateDark
            }

            val borderColor = when {
                answered && isCorrectOpt -> SoftGreen
                answered && isSelected && !isCorrectOpt -> SoftRed
                isSelected -> AccentCyan
                else -> SlateBorder.copy(alpha = 0.3f)
            }

            val emojiFeedback = when {
                answered && isCorrectOpt -> "✅ "
                answered && isSelected && !isCorrectOpt -> "❌ "
                else -> ""
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 5.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(cardColor)
                    .border(1.dp, borderColor, RoundedCornerShape(12.dp))
                    .clickable(enabled = !answered) {
                        viewModel.selectQuizOption(optIdx)
                    }
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "$emojiFeedback$optionText",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color.White
                )
            }
        }

        // Explanations View (Appears on selecting an option)
        AnimatedVisibility(visible = answered) {
            Column(modifier = Modifier.padding(vertical = 16.dp)) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SlateDark),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, AccentCyan.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "AI Explanation",
                            tint = AccentCyan,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "AI Study Insight",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = AccentCyan
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = question.explanation,
                                fontSize = 13.sp,
                                color = TextLight,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Next Button
                val isLast = currentIdx == questions.size - 1
                Button(
                    onClick = { viewModel.nextQuizQuestion() },
                    colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = if (isLast) "See Final Score 📊" else "Next Question",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(Icons.Default.ArrowForward, contentDescription = "Next", tint = Color.White, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(30.dp))
    }
}

@Composable
fun QuizResultView(
    score: Int,
    total: Int,
    isTel: Boolean,
    viewModel: EduMindViewModel,
    scrollState: androidx.compose.foundation.ScrollState
) {
    val pct = (score.toFloat() / total) * 100
    val isPass = score >= 3

    val titleMsg = when {
        score == 5 -> if (isTel) "అద్భుతం! శభాష్! 🏆" else "Perfect Score! Master! 🏆"
        score >= 3 -> if (isTel) "చాలా మంచి ప్రయత్నం! 🌟" else "Great Job! Well Done! 🌟"
        else -> if (isTel) "మరలా ప్రయత్నించు! ధైర్యం కోల్పోవద్దు. 💪" else "Keep Practicing! Don't Give Up! 💪"
    }

    val descMsg = when {
        score == 5 -> "You answered all questions correctly! Your concepts are extremely clear."
        score >= 3 -> "You did very well! Keep reviewing and you will score 100% next time."
        else -> "Don't worry, mistakes are part of learning. Solve your doubts in AI Chat and try again!"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Spacer(modifier = Modifier.height(20.dp))

        // Circular Score Graphic
        Box(
            modifier = Modifier
                .size(140.dp)
                .clip(RoundedCornerShape(70.dp))
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            if (isPass) SoftGreen.copy(alpha = 0.2f) else SoftRed.copy(alpha = 0.2f),
                            Color.Transparent
                        )
                    )
                )
                .border(
                    width = 4.dp,
                    color = if (isPass) SoftGreen else AccentYellow,
                    shape = RoundedCornerShape(70.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "$score / $total",
                    fontSize = 32.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White
                )
                Text(
                    text = "${pct.toInt()}% Score",
                    fontSize = 12.sp,
                    color = TextMuted,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = titleMsg,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            textAlign = TextAlign.Center
        )

        Text(
            text = descMsg,
            fontSize = 14.sp,
            color = TextMuted,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 8.dp, bottom = 24.dp, start = 12.dp, end = 12.dp),
            lineHeight = 20.sp
        )

        // Try Another Quiz Button
        Button(
            onClick = { viewModel.restartQuiz() },
            colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) {
            Text(
                text = if (isTel) "మరొక క్విజ్ రాయండి 🔄" else "Try Another Quiz 🔄",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }

        Spacer(modifier = Modifier.height(30.dp))
    }
}
